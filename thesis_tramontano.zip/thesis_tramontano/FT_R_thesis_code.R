# Load necessary libraries
library(edgar)
library(readr)  # Library for reading CSV files

# Read CIK numbers from the CSV file
#cik_data <- read_csv("C:/Users/alfre/OneDrive/Desktop/tesi/s&p500.csv)

# Convert CIK numbers to integers and remove any NA values
#cik_numbers <- as.integer(cik_data$CIK)


# We personally chose the CIK looking at the s&p500.csv column 'CIK'
cik_numbers <- c(1002047, 1011006, 1018724, 1018963, 1032208, 1035267, 1045810, 1048286, 1053112, 1053507, 1058290, 
                 1060391, 1065088, 1065280, 106640, 1067983, 1120193, 1121788, 1130310, 1133421, 1135152, 1138118, 1274057,
                 1282266, 1288776, 1324404, 1326380, 1326801, 1341439, 1364742, 1451505, 1467373, 1510295, 1521332, 1546640,
                 1551152, 1652044, 16732, 16918, 18926, 20171, 29989, 30625, 310764, 315852, 320187, 320193, 34088, 354950, 
                 356028, 40704, 40987, 47111, 4977, 50863, 51143, 55067, 58492, 60086, 60667, 62996, 63908, 64803, 69499, 6951,
                 701221, 702165, 712515, 723254, 72903, 73309, 7332, 754737, 764478, 764622, 77476, 78003, 793952, 796343, 80424,
                 813828, 814453, 815556, 816284, 822416, 827052, 827054, 850693, 858877, 863157, 87347, 883569, 90185, 920148,
                 921847, 92380, 927066, 935703, 945764, 949039)

# Define the filing years of interest
filing_years <- 2004:2023    

# Retrieve the Management’s Discussion and Analysis section
output <- getMgmtDisc(cik.no = cik_numbers, filing.year = filing_years)

# Print the output dataframe
print(output)




